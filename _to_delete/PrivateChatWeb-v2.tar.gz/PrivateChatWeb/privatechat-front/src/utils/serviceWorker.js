/**
 * Registra el service worker solo en la build de producción.
 *
 * En desarrollo estorbaría: se quedaría con versiones cacheadas de los módulos
 * y pelearía con el recargado en caliente de Vite. Para probar la PWA en local
 * hay que hacer `npm run build` y luego `npm run preview`.
 */
export function registrarServiceWorker() {
    if (!import.meta.env.PROD) return;
    if (!("serviceWorker" in navigator)) return;

    window.addEventListener("load", () => {
        navigator.serviceWorker
            .register("/sw.js")
            .catch((error) => console.error("No se pudo registrar el service worker:", error));
    });
}
