const RAW_SERVER_URL = (import.meta.env.VITE_CHAT_SERVER_URL || "").trim().replace(/\/+$/, "");

/**
 * Base HTTP para /upload y /file.
 * Cadena vacía = mismo origen que el front (proxy de Vite en dev).
 */
export const HTTP_BASE_URL = RAW_SERVER_URL
    .replace("wss://", "https://")
    .replace("ws://", "http://");

/**
 * Base WebSocket para /chat.
 */
export const WS_BASE_URL = RAW_SERVER_URL
    ? RAW_SERVER_URL.replace("https://", "wss://").replace("http://", "ws://")
    : `${window.location.protocol === "https:" ? "wss:" : "ws:"}//${window.location.host}`;

export function buildChatSocketUrl(userId) {
    return `${WS_BASE_URL}/chat?user=${encodeURIComponent(userId)}`;
}

export function buildHttpUrl(path) {
    return `${HTTP_BASE_URL}${path}`;
}
