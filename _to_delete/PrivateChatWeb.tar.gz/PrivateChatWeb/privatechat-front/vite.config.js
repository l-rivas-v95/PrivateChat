import { defineConfig, loadEnv } from 'vite'
import react from '@vitejs/plugin-react'

// El servidor Spring no envía cabeceras CORS para /upload y /file.
// En desarrollo el front se sirve en :5173 y el servidor en :8080, así que
// las peticiones se hacen contra el propio Vite y este las reenvía al backend.
// Así no hay que tocar nada del servidor.
export default defineConfig(({ mode }) => {
    const env = loadEnv(mode, process.cwd(), '')
    const target = env.VITE_DEV_PROXY_TARGET || 'http://localhost:8080'

    return {
        plugins: [react()],
        server: {
            proxy: {
                '/chat': { target, ws: true, changeOrigin: true },
                '/upload': { target, changeOrigin: true },
                '/file': { target, changeOrigin: true }
            }
        }
    }
})
